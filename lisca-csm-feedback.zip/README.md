# Lisca – Country Sales Managers feedback

Monthly feedback survey for Country Sales Managers, in the same design as the AW27 launch platform.

- `/` – the survey (this is the link you send to everyone)
- `/results` – results page, protected with a password

## Structure

```
public/index.html          survey page
public/results.html        results page (summary, answers by market, CSV export)
public/config.js           market list and question texts  <- edit here
public/style.css           Lisca design (same as AW27 platform)
public/logo.png            Lisca logo
netlify/functions/         submit.mjs (/api/submit), results.mjs (/api/results)
netlify/lib/common.mjs     validation, storage, password check
netlify.toml, package.json Netlify settings
```

## Publish – step by step

1. **GitHub:** create a new repository (e.g. `lisca-csm-feedback`, can be private) and upload all files from this folder
   (*Add file → Upload files*, drag the folder contents, *Commit*).
2. **Netlify:** *Add new project → Import an existing project → GitHub* → choose the repository → *Deploy*.
   Build settings are read from `netlify.toml`.
3. **Results password:** *Project configuration → Environment variables → Add a variable*
   - Key: `RESULTS_KEY`
   - Value: a strong password, e.g. `Lisca-Feedback-2026!`
     (several passwords allowed, separated by `;`, e.g. `pass1;pass2`)
   - Then *Deploys → Trigger deploy → Deploy project*.
4. Optional: *Domain management* → rename the site, e.g. `lisca-feedback.netlify.app`.
5. Open the site, send one test answer, check it on `/results`, then delete it there (click the row → *Delete this answer*).

Netlify Blobs (the storage) switches on automatically; nothing else to set up.

## How it works

- Answers are stored per **month + market + name**. If someone sends the form again for the same month,
  the new answers replace the old ones (the results page marks them "edited").
- The survey defaults to the current month; the previous two months can also be chosen.
  The same link can be reused every month.
- The browser remembers each manager's name and market for next time.
- `Promotion campaign` / `Special event`: the 1–5 rating is asked only when the answer is Yes.
- Required: name, market, all Yes/No and 1–5 answers, and at least one positive development.
  Negative developments (up to 2) and wishes for SS27/AW27 (up to 3) are optional.
- Results page: month filter, averages, which markets have not answered yet, all answers,
  CSV export (semicolon-separated, opens directly in Excel).

## Editing markets or questions

Edit `public/config.js` on GitHub (pencil icon → *Commit*). Netlify republishes automatically.
Markets not on the list can still answer via *Other…*.

## Testing without a server

Double-click `public/index.html` – it opens in **demo mode** (red bar): answers are saved only in your browser.
`public/results.html` then shows those demo answers with any password.

## Netlify free plan

A survey like this uses very little: each answer is one small JSON file, a handful of function calls per person per month.
